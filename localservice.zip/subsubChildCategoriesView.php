<?php 
	include_once 'classes/subSubCategoryClass.php';

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>subCategories</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/subCategories.css">
</head>
<body style=" background-image: url(images/bg.jpg);
		background-size: cover;">

		<div class = "containerfluid" >
				<div class="container">
						<div class = "row">
								<div class = "col-lg-12" >
									
									<div class = "col-lg-8 col-lg-offset-2" >
									 	<div id="list4">
										   	<ul class="list-group">

										     <li  class="list-group-item" style="font-size:30px; background:orange">
										     	<div class = "row">
													<div class = "col-lg-12" >								
														<div class = "col-lg-8" ><p>Estimated Total</p></div>
														<div class="col-lg-2"><p>Total:Rs</p></div>
														<div class="col-lg-2" id="amount"><p>200</p></div>
													</div>
												</div>
										     </li>


										      <li class="list-group-item" style="font-size:20px">
										    	 <div class="row">
										    	 	<div class="col-lg-12">
										    	 		<div class="col-lg-8 col-lg-offset-2"><p>Select Quantity Based On Your Requirement</p>
										    	 		</div>
										    	 	</div>
										    	 </div>
										      </li>


										      <li class="list-group-item" style="font-size:20px">
										    	 <div class="row">
										    	 	<div class="col-lg-12">
										    	 		<div class = "col-lg-2"><button class="btn btn-danger"style="width:100%">MIN</button></div>
														<div class="col-lg-8"><p align="center">Window AC</p></div>
														<div class="col-lg-2" id="amount"><button style="width:100%" class="btn btn-success">ADD</button></div>
										    	 	</div>
										    	 </div>
										      </li>

										      
										      <li class="list-group-item" style="font-size:20px">
										    	 <div class="row">
										    	 	<div class="col-lg-12">
										    	 		<div class = "col-lg-2"><button class="btn btn-danger"style="width:100%">MIN</button></div>
														<div class="col-lg-8"><p align="center">Window AC</p></div>
														<div class="col-lg-2" id="amount"><button style="width:100%" class="btn btn-success">ADD</button></div>
										    	 	</div>
										    	 </div>
										      </li>

										     
										      <li class="list-group-item" style="font-size:20px">
										    	 <div class="row">
										    	 	<div class="col-lg-12">
										    	 		<div class = "col-lg-2"><button class="btn btn-danger"style="width:100%">MIN</button></div>
														<div class="col-lg-8"><p align="center">Window AC</p></div>
														<div class="col-lg-2" id="amount"><button style="width:100%" class="btn btn-success">ADD</button></div>
										    	 	</div>
										    	 </div>
										      </li>


										       <li class="list-group-item" >
										    	 <div class="row">
										    	 	<div class="col-lg-12">
										    	 		<p style="font-size:20px;  margin:10px"><b>Rate List:</b></p>
											    	 		<ul style="font-size:15px">
											    	 			<li>Window AC at Rs:500/AC</li>
											    	 			<li>Split AC at Rs:900/AC</li>
											    	 		</ul>										 	
										    	 		<p style="font-size:20px; margin:10px"><b>What Included?</b></p>
											    	 		<ul style="font-size:15px">
											    	 			<li>Window AC at Rs:500/AC</li>
											    	 			<li>Split AC at Rs:900/AC</li>
											    	 		</ul>
										    	 	</div>
										    	 </div>
										       </li>


										       <li class="list-group-item" style="font-size:20px">
										    	 <div class="row">
										    	 	<div class="col-lg-12">
										    	 		<button class="btn btn-success btn-block btn-lg">Continue</button>
										    	 	</div>
										    	 </div>
										      </li>
										   	</ul>
										</div>
										
									</div>	
										
								</div>
						</div>				
				</div>
		</div>