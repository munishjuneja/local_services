<?php 
	$username = $_POST['username'];
	$password = $_POST['password'];
	
 ?>
<h1>Hello! This is login page</h1>
<?php 
	// echo $username;
	// echo $password;
 ?>