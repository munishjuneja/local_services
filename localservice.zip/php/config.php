<?php
define('server_name','localhost');
define('user_name' ,'root');
define('password' , 'QWERTY');
define('database', 'local_services');
 
$con=mysqli_connect(server_name,user_name,password,database);
?>