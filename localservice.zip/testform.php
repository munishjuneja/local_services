<?php 


 ?>
 <form method="post" action="getapi.php">
 	<label>contact</label>
 	<input type="text" name="contact">
 	<label>name</label>
 	<input type="text" name="contact">

 	<label>email</label>
 	<input type="text" name="contact">

 	<label>password</label>
 	<input type="text" name="contact">

 	<label>address</label>
 	<input type="text" name="contact">
 	<input type="submit" name="submit">


 </form>